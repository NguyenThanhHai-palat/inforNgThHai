from picamera2 import Picamera2
from ultralytics import YOLO
import cv2, time
import RPi.GPIO as GPIO
import requests, json, os
import serial
import pynmea2
from datetime import datetime
import threading
SERVER_URL = "http://try-removal.gl.at.ply.gg:43185"
DEVICE_ID = "GSPTHS-SM-0001-AT"
uploading = False
upload_lock = threading.Lock()
PIN_TRIG = 20
PIN_CBR = 4
PIN_ECHO = 21
PIN_TRIG2 = 23
PIN_ECHO2 = 24
PIN_TRUCK = 17
PIN_Ptrc = 22
PIN_NguyHiem = 27
isConnectserver = False
PIN_BUZZER =18
def save_local_log(data):
    with open("local_log.json", "a") as f:
        f.write(json.dumps(data) + "\n")

def check_internet():
    try:
        requests.get("http://try-removal.gl.at.ply.gg:43185", timeout=10)
        return True
    except:
        print("LOI KET NOI MANG")
        return False

def save_jpeg_atomic(folder, prefix, frame):
    if frame is None or frame.size == 0:
        raise Exception("Frame rỗng")

    ok, jpg = cv2.imencode(
        ".jpg",
        frame,
        [int(cv2.IMWRITE_JPEG_QUALITY), 65]
    )
    if not ok:
        raise Exception("Encode JPEG fail")

    name = f"{prefix}"
    tmp  = os.path.join(folder, name + ".tmp")
    final = os.path.join(folder, name + ".jpg")

    with open(tmp, "wb") as f:
        f.write(jpg.tobytes())

    os.replace(tmp, final)  # atomic
    return final

# GPS UART
ser = serial.Serial('/dev/serial0', 9600, timeout=1)
gps_data = {"lat": None, "lon": None, "speed": 0}
def save_to_temp(frame, img_back, data):
    if frame is None or img_back is None:
        return

    ts = int(time.time() * 1000)

    front = f"temp/front_{ts}.jpg"
    back  = f"temp/back_{ts}.jpg"

    save_jpeg_atomic("temp", f"front_{ts}", frame)
    save_jpeg_atomic("temp", f"back_{ts}", img_back)

    with open(f"temp/{ts}.json", "w") as f:
        json.dump(data, f)

def resend_temp():
    while True:
        time.sleep(1)  # RẤT QUAN TRỌNG
        for f in os.listdir("temp"):
            if not f.endswith(".json"):
                continue
            ts = f.replace(".json", "")
            front = f"temp/front_{ts}.jpg"
            back  = f"temp/back_{ts}.jpg"

            if not os.path.exists(front) or not os.path.exists(back):
                continue  # chưa ghi xong

            img1 = cv2.imread(front)
            img2 = cv2.imread(back)

            if img1 is None or img2 is None:
                print(ts, "- Ảnh chưa sẵn sàng")
                continue

            with open(f"temp/{ts}.json") as jf:
                data = json.load(jf)

            ok = post_image_thread(f"{SERVER_URL}/upload",img1, img2, data)
            if ok:
                os.remove(front)
                os.remove(back)
                os.remove(f"temp/{ts}.json")
                print(ts, "- Gửi bù OK")
threading.Thread(target=resend_temp, daemon=True).start()
def post_image_thread(url, frame, img_back, data):
    try:
        if frame is None or img_back is None:
            raise Exception("Ảnh None")

        ok1, jpg1 = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 65])
        ok2, jpg2 = cv2.imencode(".jpg", img_back, [int(cv2.IMWRITE_JPEG_QUALITY), 65])

        if not ok1 or not ok2:
            raise Exception("Encode JPEG fail")

        files = {
            'image1': ('front.jpg', jpg1.tobytes(), 'image/jpeg'),
            'image2': ('back.jpg',  jpg2.tobytes(), 'image/jpeg')
        }

        res = requests.post(url, files=files, data=data, timeout=(5, 30))
        if res.status_code != 200:
            raise Exception(f"HTTP {res.status_code}")
        
        print("UPLOAD OK")
        return 1

    except Exception as e:
        print("UPLOAD FAIL → LƯU LẠI", e)
        save_to_temp(frame, img_back, data)

# GPIO setup
GPIO.setmode(GPIO.BCM)
for pin in [PIN_TRUCK, PIN_Ptrc, PIN_NguyHiem]:  #GPIO LED
    GPIO.setup(pin, GPIO.OUT)
    GPIO.output(pin, GPIO.LOW)
GPIO.setup(PIN_TRIG, GPIO.OUT)
GPIO.setup(PIN_ECHO, GPIO.IN)
GPIO.setup(PIN_CBR, GPIO.IN)

# Camera setup
picam2 = Picamera2()
picam2.configure(picam2.create_video_configuration(main={"size": (640, 480), "format": "MJPEG"}))
picam2.start()

model = YOLO("yolov8n.onnx", task="detect")
model.overrides['augment'] = False
model.overrides['visualize'] = False
YOLO_CLASSES = {
    5: "bus",
    7: "truck"
}



def draw_box(frame, x1, y1, x2, y2, label): # ve khung lai
    cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 0, 0), 2)
    cv2.putText(frame, label, (x1, y1 - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)

def checkrung():
    try:
        with open('anglelog.json', 'r') as f:
            return float(f.read().strip())
    except:
        return 0

def getbattery():
    with open('batterylog.txt', 'r') as file:
        return file.read()
def getbackdist():
    with open('backdata.json', 'r') as file:
        return file.read()

def gps_reader():
    while True:
        try:
            line = ser.readline().decode('ascii', errors='replace').strip()
            if line.startswith('$GP'):
                msg = pynmea2.parse(line)
                if msg.status == 'A':
                    gps_data["lat"] = msg.latitude
                    gps_data["lon"] = msg.longitude
                    gps_data["speed"] = round(msg.spd_over_grnd * 1.85, 2)
        except:
            pass

threading.Thread(target=gps_reader, daemon=True).start()

def Getpoandspeed(val):
    if val == 0:
        return gps_data["speed"]
    elif val == 1:
        if gps_data["lat"] is not None:
            return f"{gps_data['lat']:.7f},{gps_data['lon']:.7f}"
        else:
            return "KHÔNG ĐỊNH VỊ ĐƯỢC"
    return 0

def writedataofmu(val):
    if val ==0:
     with open("lightopen.ini", "w") as f:
        f.write("yes")

    elif val ==1:
     with open("lightopen.ini", "w") as f:
        f.write("warn")

    else:
     with open("lightopen.ini", "w") as f:
        f.write("no")
def Getkc():
    GPIO.output(PIN_TRIG, True)
    time.sleep(0.00001)
    GPIO.output(PIN_TRIG, False)
    tg2= 0
    tg1=0
    timeout = time.time() + 0.02
    while GPIO.input(PIN_ECHO) == 0:
        tg1 = time.time()
        if time.time() > timeout:
            return 999
    while GPIO.input(PIN_ECHO) == 1:
        tg2 = time.time()
        if time.time() > timeout:
            return 999
    trp = tg2 - tg1
    kc = trp * 34300 / 2
    return round(kc, 2)

def Getkc2():
    GPIO.output(PIN_TRIG2, True)
    time.sleep(0.00001)
    GPIO.output(PIN_TRIG2, False)
    tg2= 0
    tg1=0
    timeout = time.time() + 0.02
    while GPIO.input(PIN_ECHO2) == 0:
        tg1 = time.time()
        if time.time() > timeout:
            return 999
    while GPIO.input(PIN_ECHO2) == 1:
        tg2 = time.time()
        if time.time() > timeout:
            return 999
    trp = tg2 - tg1
    kc = trp * 34300 / 2
    return round(kc, 2)

print("HOI THI KHOA HOC KY THUAT")

try:
    last_post_time = 0
    last_detect_time = 0
    warning_status=0
    frame_interval = 0.25   # mỗi vòng AI xử lý 0.25 s
    last_frame_time = 0
    while True:
        now = time.time()

        # chỉ lấy ảnh mới sau mỗi 0.25 s
        if now - last_frame_time < frame_interval:
            time.sleep(0.005)
            continue
        memory1 = 0
        memory2 = 0
        last_frame_time = now
        frame_yuyv = picam2.capture_array()
        frame = cv2.cvtColor(frame_yuyv, cv2.COLOR_YUV2BGR_YUYV)
        detected_truck = False
        detected_truck_back=False
        results = model(frame, imgsz=640, classes=[5,7], verbose=False,stream=False)
        for box in results[0].boxes:
            cls_id = int(box.cls[0])
            label = YOLO_CLASSES.get(cls_id, "other")
            if (label.lower() == "truck") or (label.lower() == "bus"):
                detected_truck = True
                xyxy = box.xyxy[0].cpu().numpy()
                x1, y1, x2, y2 = map(int, xyxy)
                area = (x2 - x1) * (y2 - y1)
                draw_box(frame, x1, y1, x2, y2, label)
                kmc = Getkc()
                kmt = Getkc2()
                print(f"Found vehicle at {x1},{y1},{x2},{y2}, size={area}, dist={kmc}")
                if (area > 70000) and (x2 > 330) and (kmc < 150):
                    print("Nguy hiem - Xe ben canh - KC:", kmc)
                    warning_status = 1
                    writedataofmu(0)
                    GPIO.output(PIN_NguyHiem, GPIO.HIGH)
                if (area > 70000) and (x2 > 330) and (kmt < 100):
                    print("Nguy hiem - Xe ben canh - KC:", kmc)
                    warning_status = 1
                    writedataofmu(0)
                    GPIO.output(PIN_NguyHiem, GPIO.HIGH)
                if (checkrung()>45 or checkrung()<-45):
                    warning_status = 1
                if kmt > memory1:       #Xử lý dự đoán khi xe phía trước thắng gấp
                    memory1 = kmt
                    if(memory2-memory1) > 4:
                        warning_status = 1
                        writedataofmu(0)
                    else :
                        memory2 = memory1
                    
        img_back = cv2.imread("imgback.jpg")
        if img_back is None or img_back.size == 0:
            print("Lỗi: imgback.jpg bị rỗng hoặc hỏng, bỏ qua frame")
            continue

        results_back = model(img_back, imgsz=640, classes=[5,7], verbose=False)
        for box in results_back[0].boxes:
            cls_id = int(box.cls[0])
            label = YOLO_CLASSES.get(cls_id, "other")

            if label in ("truck", "bus"):
                detected_truck_back = True
                xyxy = box.xyxy[0].cpu().numpy()
                x1, y1, x2, y2 = map(int, xyxy)
                draw_box(img_back, x1, y1, x2, y2, label)
                warning_status = 1

        if warning_status == 1:
                   if now - last_post_time >= 1:
                       if now - last_post_time >= 3:
                         last_post_time = now
                         try:
                           data = {
                            "pinlog":getbattery(),
                            "timestamp": datetime.now().isoformat(),
                            "speed": Getpoandspeed(0),
                            "geo": Getpoandspeed(1),
                            "foundtruck": detected_truck,
                            "foundtruckback": detected_truck_back,
                            "kcsau" : getbackdist(),
                            "angle": warning_status,
                            "trangthai": checkrung(),
                            "device_id": DEVICE_ID,
                            "email": "",
                            "sdt": ""}
                           threading.Thread(target=post_image_thread,args=(f"{SERVER_URL}/upload", frame,img_back, data),daemon=True).start()
                           isConnectserver = True
                           save_local_log(data)
                         except Exception as e:
                           print("Lỗi gửi ảnh:", e)
        # LED logic
        
        if detected_truck:
            GPIO.output(PIN_TRUCK, GPIO.HIGH)
            last_detect_time = now
        elif now - last_detect_time > 1:
            GPIO.output(PIN_TRUCK, GPIO.LOW)
            GPIO.output(PIN_NguyHiem, GPIO.LOW)
        warning_status = 0
        writedataofmu(2)


except KeyboardInterrupt:
    print("Dừng chương trình...")

finally:
    GPIO.output(PIN_TRUCK, GPIO.LOW)
    GPIO.cleanup()
    picam2.stop()
    cv2.destroyAllWindows()

import RPi.GPIO as GPIO
import time

# ====== GPIO SETUP ======
TRIG = 20
ECHO = 21

GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

GPIO.output(TRIG, False)
time.sleep(2)

def get_distance():
    # Phát xung TRIG
    GPIO.output(TRIG, True)
    time.sleep(0.00001)  # 10µs
    GPIO.output(TRIG, False)

    # Đợi ECHO lên mức HIGH
    start = time.time()
    timeout = start + 0.04
    while GPIO.input(ECHO) == 0:
        start = time.time()
        if start > timeout:
            return None

    # Đợi ECHO về LOW
    end = time.time()
    timeout = end + 0.04
    while GPIO.input(ECHO) == 1:
        end = time.time()
        if end > timeout:
            return None

    # Tính khoảng cách
    duration = end - start
    distance = (duration * 34300) / 2  # cm
    return round(distance, 2)

try:
    while True:
        dist = get_distance()
        if dist:
            print(f"📏 Distance: {dist} cm")
        else:
            print("❌ Không đọc được")
        time.sleep(0.5)

except KeyboardInterrupt:
    print("🛑 Stop")
    GPIO.cleanup()
